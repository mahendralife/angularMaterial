var app=angular.module('search', ['ngMaterial']);

app.controller('DemoCtrl', DemoCtrl);
var url='services/list.php';
var url1='services/list1.php';

function DemoCtrl ($timeout, $q, $log) {
    var self = this;

    self.simulateQuery = false;
    self.isDisabled    = false;

    // list of `state` value/display objects
    self.states        = loadAll();
    self.querySearch   = querySearch;
    self.selectedItemChange = selectedItemChange;
    self.searchTextChange   = searchTextChange;

    self.newState = newState;

    function newState(state) {
      alert("Sorry! You'll need to create a Constitution for " + state + " first!");
    }

    // ******************************
    // Internal methods
    // ******************************

    /**
     * Search for states... use $timeout to simulate
     * remote dataservice call.
     */
    function querySearch (query) {
      var results = query ? self.states.filter( createFilterFor(query) ) : self.states,
          deferred;
      if (self.simulateQuery) {
        deferred = $q.defer();
        $timeout(function () { deferred.resolve( results ); }, Math.random() * 1000, false);
        return deferred.promise;
      } else {
        return results;
      }
    }

    function searchTextChange(text) {
      $log.info('Text changed to ' + text);
    }

    function selectedItemChange(item) {
      $log.info('Item changed to ' + JSON.stringify(item));
    }

    /**
     * Build `states` list of key/value pairs
     */
    function loadAll() {
      var allStates = 'Alabama, Alaska, Arizona, Arkansas, California, Colorado, Connecticut, Delaware,\
              Florida, Georgia, Hawaii, Idaho, Illinois, Indiana, Iowa, Kansas, Kentucky, Louisiana,\
              Maine, Maryland, Massachusetts, Michigan, Minnesota, Mississippi, Missouri, Montana,\
              Nebraska, Nevada, New Hampshire, New Jersey, New Mexico, New York, North Carolina,\
              North Dakota, Ohio, Oklahoma, Oregon, Pennsylvania, Rhode Island, South Carolina,\
              South Dakota, Tennessee, Texas, Utah, Vermont, Virginia, Washington, West Virginia,\
              Wisconsin, Wyoming';

      return allStates.split(/, +/g).map( function (state) {
        return {
          value: state.toLowerCase(),
          display: state
        };
      });
    }

    /**
     * Create filter function for a query string
     */
    function createFilterFor(query) {
      var lowercaseQuery = angular.lowercase(query);

      return function filterFn(state) {
        return (state.value.indexOf(lowercaseQuery) === 0);
      };

    }

/*
function DemoCtrl ($timeout, $log,$scope,$http,GetCountryService,filterFilter)
{

$scope.list={};
$scope.searchText = "";
$scope.isDisabled = false;
$scope.noCache = true;
$scope.simulateQuery=false;

/*
$http.get(url).then(function(response) {
$scope.list=response.data;
  $scope.trending=true;

  });


function newState(state) {
      alert("Sorry! You'll need to create a Constitution for " + state + " first!");
    }
$scope.searchTextChange = function (str)
{

   if(str)
   {

     return $http.get('//maps.googleapis.com/maps/api/geocode/json', {
     params: {
       address: str,
       sensor: false
     }
   }).then(function(response){
     return response.data.results.map(function(item){
       return $scope.list=item;

     });
   });


        /* $http.get(url1).then(function(response)
         {  $scope.trending=false;
            return  $scope.list=response.data;

          });*/
         }
//else
//{

    //return $scope.list
//}

         /*
         //console.log($scope.Person);
        //  return filterFilter(
          return  $scope.Person//,str      );
       }


              $scope.selectedItemChange = function (item) {
                if(item)
                {
                $log.info(item)
                }
              }

}
*/
app.factory('GetCountryService', function ($http,filterFilter) {
        return {
            getCountry: function(str) {

				        var url = "services/list.php?token="+str;
                return $http.get(url)
                    .then(function(response) {

                          console.log(response)
                            return response.data;


                    }, function(response) {
                        // something went wrong
                        //return $q.reject(response.data.records);
                    });
            },
            fileterData: function(data){
                return filterFilter(this.getCountry(data),data);
            }
        };
    });
