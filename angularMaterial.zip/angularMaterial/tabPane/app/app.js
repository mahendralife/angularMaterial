var app=angular.module('tabPane',['ngMaterial','ngMessages']);

app.config(function($mdThemingProvider) {
  $mdThemingProvider.theme('default')
  $mdThemingProvider.theme('default')
  .primaryPalette('light-blue', {
    'default': '800',
    })
  .accentPalette('grey', {
    'default': '800'

  });
});


app.run(function($log,$rootScope,  $mdDialog, $mdMedia,$window){
  $window.onload= function(){
    var ele=angular.element(document.querySelector('html'));
    ele.removeClass('isLoading');
  }

  $log.info("Angular Material is reday for work")


});
//directive for clear field
app.directive("close", function($parse){
  return {
    restrict: 'A',
    link: function(scope,ele,attrs){
      var model = $parse(attrs.close);
      var modelSetter = model.assign;

      ele.bind("click", function(){
          scope.$apply(function(){
            modelSetter(scope);}
          );
      });
    }

  }

});

app.controller('tabs', tabs);
function tabs($log,$scope,$http,filterFilter,$q,  $mdDialog, $mdMedia)
{
  that=$scope;
  that.selectedIndex=0;
  var  colorList={};
  var cards={};
//auto complte tool
  that.showTabs=function(index){
    that.selectedIndex=index;
  }

//auto complete tool
var url="services/list.php";
var colorurl="services/colorList.json";
var cardUrl="services/customList.php";

$http.get(cardUrl).then(function(response)
{
  cards=response.data;
  console.log($scope.cards);
});

$scope.searchCrads= function(str){
  if(str){

  return filterFilter(cards,str);
}
else {
return cards;
}

}

$scope.chnageCards= function(item){
  console.log(item);
}
$scope.selectedColorChange= function(color){
  $scope.colorview=color;
  console.log(color);

}








$http.get(url).then(function(response)
{
$scope.Person=response.data.records;
});

$http.get(colorurl).then(function(response)
{
colorList=response.data;

});


$scope.isDisabled = false;
$scope.noCache = false;
 $scope.selectedItemChange = function (item) {
   if(item)
   {
   $log.info(item)
   }
 }

 $scope.searchTextChange = function (str) {
    if(str){
    return filterFilter($scope.Person,str);
  }
  else {
  return $scope.Person;
  }
 }



$scope.data={};
$scope.clear=function(){
$scope.fileView="";
}
 $scope.fileNameChanged = function (ele, name, form) {
  var files = ele.files[0];
  $scope.data.coverphoto=files.name;
  //read file
  fileData=new FileReader();
  fileData.readAsDataURL(files);
  fileData.onload =function(e){
    var data=e.target.result;
    $scope.fileView=data;
    console.log(data);
  }
 }

//submit form-group
that.submitForm= function(form,data){
//  alert(form.$valid);
if(form.$valid)
{

}
else
{
    angular.forEach(form.$error.required, function(field){
      field.$dirty=true;
    })
}
}

//change color

$scope.searchColor= function(color){
  if(color){

  return filterFilter(colorList,color);
}
else {
return colorList;
}

}
$scope.selectedColorChange= function(color){
  $scope.colorview=color;
  console.log(color);

}

}
