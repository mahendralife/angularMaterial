{
"records":
[
{"sno":1,"country":"Afghanistan"},
{"sno":2,"country":"Akrotiri"},
{"sno":3,"country":"Albania"},
{"sno":4,"country":"Algeria"},
{"sno":5,"country":"American Samoa"},
{"sno":6,"country":"Andorra"},
{"sno":7,"country":"Angola"},
{"sno":8,"country":"Anguilla"},
{"sno":9,"country":"Antarctica"},{"sno":10,"country":"Antigua and Barbuda"},
{"sno":11,"country":"Argentina"},{"sno":12,"country":"Armenia"},{"sno":13,"country":"Aruba"},{"sno":14,"country":"Ashmore and Cartier Islands"},{"sno":15,"country":"Australia"},
{"sno":16,"country":"Austria"},{"sno":17,"country":"Azerbaijan"},{"sno":18,"country":"Bahamas, The"},{"sno":19,"country":"Bahrain"},{"sno":20,"country":"Bangladesh"},
{"sno":21,"country":"Barbados"},{"sno":22,"country":"Bassas da India"},{"sno":23,"country":"Belarus"},{"sno":24,"country":"Belgium"},{"sno":25,"country":"Belize"},
{"sno":26,"country":"Benin"},{"sno":27,"country":"Bermuda"},{"sno":28,"country":"Bhutan"},{"sno":29,"country":"Bolivia"},{"sno":30,"country":"Bosnia and Herzegovina"},
{"sno":31,"country":"Botswana"},{"sno":32,"country":"Bouvet Island"},{"sno":33,"country":"Brazil"},{"sno":34,"country":"British Indian Ocean Territory"},
{"sno":35,"country":"British Virgin Islands"},{"sno":36,"country":"Brunei"},{"sno":37,"country":"Bulgaria"},{"sno":38,"country":"Burkina Faso"},{"sno":39,"country":"Burma"},
{"sno":40,"country":"Burundi"},{"sno":41,"country":"Cambodia"},{"sno":42,"country":"Cameroon"},{"sno":43,"country":"Canada"},{"sno":44,"country":"Cape Verde"},
{"sno":45,"country":"Cayman Islands"},{"sno":46,"country":"Central African Republic"},{"sno":47,"country":"Chad"},{"sno":48,"country":"Chile"}]
}
