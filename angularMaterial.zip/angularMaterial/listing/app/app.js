var app=angular.module("listing",["ngMaterial"])

app.controller("AppCtrl", function($scope){
  $scope.imagePath = 'https://c5.staticflickr.com/6/5666/20334409940_c573e52b82_n.jpg';

  var array=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33];
  var item=numToColumn(array.length);

  console.log(item);

});

function numToColumn(data){
  if(data){
  var length=data;
  var column=0;
  var itemL=(length/3).toString().split('.')[0];
  var itemR=(length/3).toString().split('.')[1];
  if(itemL){
    column=parseInt(itemL);
  }
  if(itemR){
    column=column+1;
  }
  return column
  }
  else{
    return;
  }

}
