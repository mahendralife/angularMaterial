var app=angular.module('box',['ngMaterial','ngMessages']);

app.controller('AppCtrl', function($scope, $mdDialog, $mdMedia, $http,  $mdToast) {
var $request={
  url:"services/color.min.json",
  method:"GET"
}
$http($request).then(success);
function success(response){
  $scope.list=response.data;
}

  $scope.status = '  ';
  $scope.customFullscreen = $mdMedia('xs') || $mdMedia('sm');

  $scope.showTabDialog = function(ev) {

    $mdDialog.show({
      controller: DialogController,
      templateUrl: 'tpl.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      scope:$scope,
       preserveScope: true,
      clickOutsideToClose:true
    }).then(function(answer) {
          }, function() {
          $scope.status = 'You cancelled the dialog.';
      });
  };

//push color
$scope.addNewColor= function(data,form){

if(form.$valid)
{
  var newcolor={};
  var rgb=convertHex(data.hex);
  rgb="("+rgb.r+","+rgb.g+","+rgb.b+")"
  data["rgb"]=rgb;
  $scope.list.push(data);
  $mdDialog.cancel();

        var toast = $mdToast.simple()
        .textContent('Color ' + data.name +' has been added' )
        //.action('UNDO')
        //.highlightAction(true)
        .highlightClass('md-primary')// Accent is used by default, this just demonstrates the usage.
        .position("top, right").hideDelay(5000);
      $mdToast.show(toast);
}
else
{
  angular.forEach(form.$error.required,function(field){
    field.$dirty=true;
  })
}
}

//alert
$scope.showSimpleToast = function() {


  var toast = $mdToast.simple()
        .textContent('Marked as read')
        .action('UNDO')
        .highlightAction(true)
        .highlightClass('md-primary')// Accent is used by default, this just demonstrates the usage.
        .position("top, right").hideDelay(5000);

      $mdToast.show(toast).then(function(response) {
        if ( response == 'ok' ) {
          alert('You clicked the \'UNDO\' action.');
        }
      });


}


});

function DialogController($scope, $mdDialog)
{
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  $scope.answer = function(answer) {
    $mdDialog.hide(answer);
  };
}

function convertHex(hex)
{
	 var rgb={};
    hex = hex.replace('#','');
    r = parseInt(hex.substring(0,2), 16);
    g = parseInt(hex.substring(2,4), 16);
    b = parseInt(hex.substring(4,6), 16);
		rgb['r']=r;
    rgb['g']=g;
    rgb['b']=b;
    return rgb;

}
