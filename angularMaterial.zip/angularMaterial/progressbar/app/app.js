var app=angular.module('progressbar',['ngMaterial']);

app.run(function($log){
  $log.info("applocation is ready to work");
});

app.controller("progressCtrl", function($log,$scope,$rootScope){


});
